%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (c) Rafeef Abu-Gharbieh, Karin Althoff, Ghassan Hamarneh 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Line Detection Using Hough Transform
====================================
by:
	Ghassan Hamarneh
	Karin Althoff
	Rafeef Abu-Gharbieh

- uncompress project.zip to directory DIRX
     you should obtain the following files:
	
	1. CBabout.m
	2. CBedge.m
	3. CBexit.m
	4. CBhough.m
	5. CBimage.m
	6. CBunhough.m
	7. CVedge.m
	8. CVhough.m
	9. CVimagem
	10.CVline.m
	11.CVproj.m
	12.CVunhough.m
	13.CVproj.mat
	14.image.bmp
	15.readme.txt
	16.readpgm.m
	17.rita.m
	18.rowedges.m
	19.calcw123_1.m
	
- run MATLAB 5.3 with Image Processing Toolbox
- change directory to DIRX or add it to MATLABs path
- run >>CVproj